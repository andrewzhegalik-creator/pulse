//
//  ContainerView.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/24/21.
//

import UIKit

class ContainerView: UIView {
    let circularView = CircularProgressBar()
    
    let circleLayer = CAShapeLayer()
    let progressLayer = CAShapeLayer()
    //let miniView = UIView()
    let miniCircleLayer = CAShapeLayer()
    let miniCircleContainerLayer = CAShapeLayer()
    
    override func layoutSubviews() {
        circularView.frame = frame
        //addSubview(circularView)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }
    
    func setup() {
        let circlePath = UIBezierPath(arcCenter: CGPoint(x:  frame.width / 2, y:  frame.height / 2), radius: (frame.width / 2) - 10.0, startAngle: -.pi / 2, endAngle: 3 * .pi / 2, clockwise: true)
        
    
        let colorOne = UIColor(red: 113.0/255.0, green: 102.0/255.0, blue: 249.0/255.0, alpha: 1)
        let colorTwo = UIColor(red: 113.0/255.0, green: 102.0/255.0, blue: 249.0/255.0, alpha: 0.4)
        
        circleLayer.path = circlePath.cgPath
        circleLayer.fillColor = UIColor.clear.cgColor
        circleLayer.lineCap = .round
        circleLayer.lineWidth = 20.0
        circleLayer.strokeColor = colorTwo.cgColor
        
        progressLayer.path = circlePath.cgPath
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineCap = .round
        progressLayer.lineWidth = 20.0
        progressLayer.strokeEnd = 0
        progressLayer.strokeColor = colorOne.cgColor
        
        
        let circleCenter = CGPoint(x: bounds.midX, y: bounds.midY)
        let miniPath = CGPath(ellipseIn: CGRect(x: -5, y: -((frame.width / 2) - 10.0) - 5, width: 10, height: 10), transform: nil)
        miniCircleLayer.path = miniPath
        miniCircleLayer.position = circleCenter
        miniCircleLayer.fillColor = UIColor.white.cgColor
        
        let miniContainerPath = CGPath(ellipseIn: CGRect(x: -10, y: -((frame.width / 2) - 10.0) - 10, width: 20, height: 20), transform: nil)
        
        miniCircleContainerLayer.path = miniContainerPath
        miniCircleContainerLayer.position = circleCenter
        miniCircleContainerLayer.fillColor = colorOne.cgColor
        
        layer.addSublayer(circleLayer)
        layer.addSublayer(progressLayer)
        layer.addSublayer(miniCircleContainerLayer)
        layer.addSublayer(miniCircleLayer)
        
    }
    
    func myAnimation(duration: TimeInterval) {
        let circleProgressAnimation = CABasicAnimation(keyPath: "strokeEnd")
        
        circleProgressAnimation.duration = 20
        circleProgressAnimation.fromValue = 0
        circleProgressAnimation.toValue = 1
        
        circleProgressAnimation.fillMode = .forwards
        circleProgressAnimation.isRemovedOnCompletion = false
        
        let animation = CABasicAnimation(keyPath: "transform.rotation")
        animation.fromValue = 0
        animation.toValue = 2 * CGFloat.pi
        animation.duration = 20
        animation.isRemovedOnCompletion = false
        
        miniCircleLayer.speed = 1.0
        progressLayer.speed = 1.0
        
        miniCircleLayer.add(animation, forKey: nil)
        progressLayer.add(circleProgressAnimation, forKey: "progressAnim")
    }
    
    func deleteAnimations() {
        miniCircleLayer.speed = 0.0
        progressLayer.speed = 0.0
    }
}
