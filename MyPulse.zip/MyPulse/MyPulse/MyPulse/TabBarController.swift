//
//  TabBarController.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/19/21.
//

import UIKit

class TabBarController: UITabBarController {

   
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        print(tabBar.frame.size.height, "!!!!")
        //tabBar.frame.size.height = 92
        //tabBar.frame.origin.y = tabBar.frame.origin.y - 92
        
        
        
        //tabBar.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3).isActive = true
        print(tabBar.frame.size.height, "!!!!")
        
        guard let items = tabBar.items else { return }
        
        for item in items {
            item.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -20.0)
        }
        
        let roundPath = UIBezierPath(roundedRect: tabBar.bounds, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 20, height: 20))
        let mask = CAShapeLayer()
        mask.path = roundPath.cgPath
        tabBar.layer.mask = mask
        tabBar.layer.masksToBounds = true
    }
    
    override func viewWillLayoutSubviews() {
        //tabBar.frame.size.height = view.frame.height / 8
        
    }
}
