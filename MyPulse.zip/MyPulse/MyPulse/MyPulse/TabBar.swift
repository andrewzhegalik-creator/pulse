//
//  TabBar.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/24/21.
//

import UIKit

class TabBar: UITabBar {
    override func sizeThatFits(_ size: CGSize) -> CGSize {
        var size = super.sizeThatFits(size)
        
        if UIScreen.main.nativeBounds.height > 2208 {
            size.height = 115
        } else {
            size.height = 82
        }
        return size
    }
}
