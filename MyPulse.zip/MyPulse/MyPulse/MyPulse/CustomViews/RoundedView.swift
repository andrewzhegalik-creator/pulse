//
//  RoundedView.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 3/1/21.
//

import UIKit

class RoundedView: UIView {
    override func layoutSubviews() {
        layer.cornerRadius = 12.5
        layer.backgroundColor = UIColor(red: 0.969, green: 0.969, blue: 0.976, alpha: 0.6).cgColor
        layer.borderWidth = 1
        layer.borderColor = UIColor(red: 0.922, green: 0.914, blue: 0.941, alpha: 1).cgColor
        layer.masksToBounds = true
    }
}
