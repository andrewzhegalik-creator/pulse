//
//  RoundButton.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/25/21.
//

import UIKit

class RoundButton: UIButton {

    override func layoutSubviews() {
        super.layoutSubviews()
        
        layer.cornerRadius = bounds.height / 2.26
        print("cornerRadius = \(layer.cornerRadius), height = \(bounds.height)")
        layer.masksToBounds = true
    }

}
