//
//  СircularProgressBar.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/23/21.
//

import UIKit


class CircularProgressBar: UIView {
    private var circleLayer = CAShapeLayer()
    private var progressLayer = CAShapeLayer()
    private var inputCircleLayer = CAShapeLayer()
    
    var newPath = UIBezierPath()
    
    lazy var miniCircleView: UIView = {
        let  view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .white
        return view
    }()
    
    private func setup() {
        self.clipsToBounds = false
        
        
        
        self.addSubview(self.miniCircleView)
        NSLayoutConstraint.activate([
            self.miniCircleView.widthAnchor.constraint(equalToConstant: 10),
            self.miniCircleView.heightAnchor.constraint(equalToConstant: 10)
        ])
    }
    
    var progress: Float = 0 {
        willSet (newValue) {
            progressLayer.strokeEnd = CGFloat(newValue)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createCirclePath()
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        createCirclePath()
        setup()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.miniCircleView.layer.cornerRadius = self.miniCircleView.frame.width / 2.0
        
        self.miniCircleView.center = self.getPoint(for: -90)
        print("center point: \(self.miniCircleView.center)")
    }
    
    private func getPoint(for angle: Int) -> CGPoint {
        let radius = 107.0
        
        let radian = Double(angle) * Double.pi / Double(180)
        
        let newCenterX =  Double(radius) * cos(radian)
        let newCenterY =  Double(radius) * sin(radian)
        
        return CGPoint(x: newCenterX, y: newCenterY)
    }
    
    func startAnimating() {
        let path = UIBezierPath(ovalIn: frame)
        let initialPoint = self.getPoint(for: -90)
        path.move(to: initialPoint)
        
        for angle in -89...0 { path.addLine(to: self.getPoint(for: angle)) }
        for angle in 1...270 { path.addLine(to: self.getPoint(for: angle)) }
        path.close()
        
        self.animate(view: self.miniCircleView, path: path)
        
    }
    
    private func animate(view: UIView, path: UIBezierPath) {
        let animation = CAKeyframeAnimation(keyPath: "position")
        animation.path = path.cgPath
        
        animation.repeatCount = 1
        animation.duration = 2
        layer.add(animation, forKey: "miniCircleViewAnimation")
    }
    
    func createCirclePath() {
        let circlePath = UIBezierPath(arcCenter: CGPoint(x:  self.frame.width / 2, y:  self.frame.height / 2), radius: 107.0, startAngle: -.pi / 2, endAngle: 3 * .pi / 2, clockwise: true)
        
//        let circlePath = UIBezierPath(arcCenter: center, radius: 50.0, startAngle: -.pi / 2, endAngle: 3 * .pi / 2, clockwise: true)
        
        
//        let circlePath = UIBezierPath(ovalIn: frame)
        
    
        let colorOne = UIColor(red: 113.0/255.0, green: 102.0/255.0, blue: 249.0/255.0, alpha: 1)
        let colorTwo = UIColor(red: 113.0/255.0, green: 102.0/255.0, blue: 249.0/255.0, alpha: 0.4)
        
//        let animation = CAKeyframeAnimation(keyPath: "HelloAnimation")
//        animation.duration = 3
//        animation.repeatCount = 5
//        animation.path = circlePath.cgPath
//
//        let squareView = UIView()
//        squareView.frame = CGRect(x: 0, y: 0, width: 10, height: 10)
//        squareView.center = self.getPoint(for: -180)
//        squareView.backgroundColor = .orange
//        self.addSubview(squareView)
//        squareView.layer.add(animation, forKey: nil)
        
        circleLayer.path = circlePath.cgPath
        circleLayer.fillColor = UIColor.clear.cgColor
        circleLayer.lineCap = .round
        circleLayer.lineWidth = 20.0
        circleLayer.strokeColor = colorTwo.cgColor
        
        progressLayer.path = circlePath.cgPath
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineCap = .round
        progressLayer.lineWidth = 20.0
        progressLayer.strokeEnd = 0
        progressLayer.strokeStart = 1
        progressLayer.strokeColor = colorOne.cgColor
        
//        let path = UIBezierPath(ovalIn: CGRect(x: 150, y: 150, width: 20.0, height: 20.0))
//        inputCircleLayer.path = path.cgPath
//        inputCircleLayer.fillColor = UIColor.orange.cgColor
//        inputCircleLayer.lineWidth = 1
//        inputCircleLayer.strokeColor = UIColor.black.cgColor
        
        
        layer.addSublayer(circleLayer)
        layer.addSublayer(progressLayer)
    }
    
    func progressAnimation(duration: TimeInterval, fromValue: Float, toValue: Float) {
        
        let circleProgressAnimation = CABasicAnimation(keyPath: "strokeEnd")
        
        circleProgressAnimation.duration = 20
        circleProgressAnimation.fromValue = 0
        circleProgressAnimation.toValue = 1
        
        circleProgressAnimation.fillMode = .both
        circleProgressAnimation.isRemovedOnCompletion = false
        
        let circlePath = UIBezierPath(arcCenter: CGPoint(x: frame.width / 2, y: frame.height / 2), radius: 107.0, startAngle: -.pi / 2, endAngle: 3 * .pi / 2, clockwise: true)
        
        let animation = CAKeyframeAnimation(keyPath: #keyPath(CALayer.position))
        //let animation = CABasicAnimation(keyPath: "lineEnd")
        animation.duration = 20
        animation.path = circlePath.cgPath
        miniCircleView.layer.add(animation, forKey: "hoalanimation")
        
        progressLayer.add(circleProgressAnimation, forKey: "progressAnim")
    }
}
