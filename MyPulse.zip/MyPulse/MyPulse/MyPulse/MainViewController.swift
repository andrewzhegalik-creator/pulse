//
//  ViewController.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/19/21.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    
       // self.navigationController?.pushViewController(tabBarController, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let tabBarController = storyboard.instantiateViewController(withIdentifier: "TabBarController") as! TabBarController
        
        
        tabBarController.modalPresentationStyle = .overCurrentContext
        present(tabBarController, animated: false, completion: nil)
    }
}

