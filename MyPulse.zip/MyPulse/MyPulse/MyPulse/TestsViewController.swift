//
//  TestsViewController.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/19/21.
//

import UIKit

class TestsViewController: BaseViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
