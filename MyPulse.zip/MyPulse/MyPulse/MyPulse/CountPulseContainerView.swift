//
//  CountPulseContainerView.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/25/21.
//

import UIKit

class CountPulseContainerView: UIView {

}
