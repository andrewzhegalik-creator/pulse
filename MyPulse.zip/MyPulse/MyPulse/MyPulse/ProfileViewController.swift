//
//  ProfileViewController.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/19/21.
//

import UIKit

class ProfileViewController: BaseViewController {

    @IBOutlet weak var stackView: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

}
