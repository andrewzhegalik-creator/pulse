//
//  GraphicViewController.swift
//  MyPulse
//
//  Created by Andrew Zhegalik on 2/19/21.
//

import UIKit

class GraphicViewController: BaseViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleLabel.text = "History"
    }
    
    
}
